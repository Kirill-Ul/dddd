from flask import Flask,render_template

app = Flask(__name__)

@app.route('/user/<name>', methods=['GET'])

def users(name:str):
    name = name.upper()
    return render_template('index.html', name=name)

@app.route('/', methods=['GET'])
def students():
    return render_template('st_index.html', name=[{'имя': 'Кирилл', 'возраст': 27, 'должность': 'Механик',
                                                                 'стаж': 5, 'гражданство': 'Россия' },
                                                                                 {'имя': 'Александр', 'возраст': 32,
                                                                                  'должность': 'Инженер', 'стаж': 7,
                                                                                  'гражданство': 'Россия' },
                                                                                 {'имя': 'Иван', 'возраст': 40,
                                                                                 'должность': 'Слесарь', 'стаж': 10,
                                                                                 'гражданство': 'Россия' }])



if __name__ == '__main__':
    app.run(debug=True)